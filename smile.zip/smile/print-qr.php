
<html>
<head>
	<title></title>
</head>
<body onload="printImage()">

</body>
</html>
<?php 
	header("Location: product-list-all.php");
	die();
?>