
/*
$(function () {
  
  $('#selectall').toggle(
          function() {
              $('.co-item').prop('checked', true);
          },
          function() {
              $('.co-item').prop('checked', false);
          }
      ); 
});
   
*/




