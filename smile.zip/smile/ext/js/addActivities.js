
$(document).ready(function() {

$('#confirm-delete').on('show.bs.modal', function(e) {
                    
             })  
 



});