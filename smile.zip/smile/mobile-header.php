
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <meta name="description" content="SMiLE Project">
        <meta name="author" content="Radu Marian Tutunaru, Mujtaba Mehdi">
   
        <!-- <link rel="shortcut icon" href="../../assets/ico/favicon.ico"> -->

        <title></title>
        <!-- Select box plugin fix for Bootstrap-->
        <link href="ext/css/bootstrap-select.min.css" rel="stylesheet">

        <!-- Bootstrap core CSS -->
        <link href="ext/css/bootstrap.min.css" rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="ext/css/style.css" rel="stylesheet">
        <link href="ext/js/select2/select2-bootstrap.css">
        
        <link href="ext/css/footable.standalone.css" rel="stylesheet" type="text/css" />
        <link href="ext/css/footable.core.css" rel="stylesheet" type="text/css" />

        <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
        
      <link rel="stylesheet" href="http://cdn.leafletjs.com/leaflet-0.7.2/leaflet.css" />
    </head>

    <body>



